# Direção visual — Controle de Validade

## Exploração de estilos

- **Caderno de estoque** — interface clara inspirada em etiquetas organizadas, com verde escuro e superfícies de papel; transmite cuidado e leitura fácil. Probabilidade: **0,04**.
- **Armazém modular** — blocos compactos e utilitários, com contraste forte e sinais de categoria em primeiro plano; transmite rapidez de conferência. Probabilidade: **0,07**.
- **Balcão sereno** — cartões espaçados, tons minerais quentes e controles arredondados; transmite calma e acolhimento. Probabilidade: **0,02**.

## Direção escolhida: Caderno de estoque

### Movimento de design
Minimalismo editorial utilitário: conteúdo primeiro, decoração quase nenhuma, hierarquia clara e um toque acolhedor de material impresso.

### Princípios centrais
Uma tarefa por área; duas abas principais fixas; informação escaneável; estados sempre acompanhados por texto e cor; administração disponível sem competir com o acompanhamento diário.

### Filosofia de cores
Fundo marfim muito claro (#F6F7F3), superfícies brancas e texto verde-carvão (#18332B). Verde profundo (#176B50) é a ação principal. Os estados preservam o código pedido: verde para Normal, amarelo para 3 meses, laranja para 2 meses, vermelho para 1 mês e cinza-carvão para Vencidos. A área Atenção usa âmbar suave. Contraste de texto permanece suficiente mesmo dentro dos chips de status.

### Paradigma de layout
Mobile-first, coluna única com largura confortável; cabeçalho compacto; busca visível; resumo enxuto; grupos de produtos empilhados; folhas/modais para detalhe e gestão administrativa; navegação inferior fixa com as duas abas indicadas. Em telas maiores, ampliar a área de conteúdo sem transformar o app em dashboard denso.

### Elementos de assinatura
Pequenos marcadores verticais de status, contagem por grupo e marca geométrica inspirada em uma folha de calendário com marcação de validade. Nenhum gráfico, imagem de produto, lote, desconto ou seção adicional.

### Filosofia de interação
Toques confortáveis, rótulos diretos em português, formulários sem campos extras, confirmação explícita antes de excluir, retorno breve após salvar e estado vazio que orienta a próxima ação.

### Animação
Somente transições discretas de opacidade/posição para folhas e avisos; respeitar `prefers-reduced-motion`; sem animação de decoração.

### Sistema tipográfico
Usar a pilha de fontes de sistema do projeto para carregamento rápido e boa leitura no Android. Títulos sem serifa, peso semibold; texto de produto e formulários com tamanho confortável; números de quantidade e datas claramente distinguíveis.

### Essência e voz da marca
Made by Heron; confiável, direta e sem ruído. Microcopy objetiva, cordial e sempre em português brasileiro.

### Wordmark / logo
Símbolo quadrado próprio: calendário/etiqueta de validade de linhas simples e uma marca de confirmação, fundo verde profundo de borda a borda e traço claro. Sem texto pequeno e sem imagem fotográfica.

### Cor de assinatura
Verde profundo #176B50, complementado pelos sinais de status previstos pelo produto.

## Ativos

O aplicativo é um utilitário interno, não precisa de fotos nem de ilustrações. O ícone próprio será vetorial e reutilizado como favicon e ícone do PWA; não serão incorporadas imagens de bancos de imagens.