# Controle de Validade — cópia do projeto

Esta cópia contém os arquivos-fonte rastreados no commit `b92b2e85f3ba065824822d926b67689f341b17d1`. Inclui interface, servidor, esquema e migrações do banco, testes, imagens, manifesto e configuração do PWA.

## Para restaurar o código

- Extraia este ZIP.
- Use Node.js 22 e pnpm 10.18.0.
- Instale as dependências com `pnpm install --frozen-lockfile`.
- Para executar localmente, configure `DATABASE_URL` para um banco MySQL compatível e execute `pnpm db:migrate`; depois `pnpm dev`.
- Para gerar a versão de produção, execute `pnpm build`; o servidor inicia com `pnpm start`.

O ZIP não inclui `node_modules`, arquivos compilados, credenciais, `.env`, nem dados reais do banco online. As dependências podem ser reinstaladas pelo lockfile.

A cópia Git complementar preserva o histórico de commits, sem incluir a configuração local do remote ou credenciais de acesso.
