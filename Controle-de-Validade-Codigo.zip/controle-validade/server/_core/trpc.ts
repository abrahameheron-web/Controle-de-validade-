import { NOT_ADMIN_ERR_MSG, UNAUTHED_ERR_MSG } from "@shared/const";
import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";

const t = initTRPC.context<TrpcContext>().create({ transformer: superjson });

export const router = t.router;
export const publicProcedure = t.procedure;

const requireUser = t.middleware(async ({ ctx, next }) => {
  if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  return next({ ctx: { ...ctx, user: ctx.user } });
});

export const protectedProcedure = t.procedure.use(requireUser);

export const adminProcedure = t.procedure.use(t.middleware(async ({ ctx, next }) => {
  if (!ctx.user || ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
  }
  return next({ ctx: { ...ctx, user: ctx.user } });
}));

export const employeeProcedure = t.procedure.use(t.middleware(async ({ ctx, next }) => {
  if (!ctx.employee) throw new TRPCError({ code: "UNAUTHORIZED", message: "Faça login para continuar." });
  return next({ ctx: { ...ctx, employee: ctx.employee } });
}));

export const employeeAdminProcedure = t.procedure.use(t.middleware(async ({ ctx, next }) => {
  if (!ctx.employee || ctx.employee.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Acesso exclusivo do administrador." });
  }
  return next({ ctx: { ...ctx, employee: ctx.employee } });
}));
